﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISEEService.DataContract
{
   public class close_job
    {
        public string job_id { get; set; }
        public string summary { get; set; }
        public string action { get; set; }
        public string result { get; set; }
        public string transfer_to { get; set; }
        public string fix_date { get; set; }
        public string invoice_no { get; set; }
        public string signnature { get; set; }
        public string userid { get; set; }
        public tbt_job_detail job_detail { get; set; }
        public  List<tbt_job_checklist> job_checklists { get; set; }
        public List<job_file> job_images { get; set; }
        public List <tbt_job_image> image_detail { get; set; }
        public List<tbt_job_part> job_parts { get; set; }

    }
}
